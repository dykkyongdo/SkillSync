#!/bin/bash

# Set environment variables
export JWT_SECRET="mySecretKey123456789012345678901234567890"
export JWT_EXPIRATION="86400000"
export SPRING_DATASOURCE_USERNAME="postgres"
export SPRING_DATASOURCE_PASSWORD="password"

# Start the Spring Boot application
./mvnw spring-boot:run
