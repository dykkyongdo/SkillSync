package com.skillsync_backend.model;

public enum MembershipStatus {
    INVITED,
    ACTIVE,
    REJECTED
}
