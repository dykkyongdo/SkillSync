package com.skillsync_backend.security;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String msg) { super(msg); }
}
