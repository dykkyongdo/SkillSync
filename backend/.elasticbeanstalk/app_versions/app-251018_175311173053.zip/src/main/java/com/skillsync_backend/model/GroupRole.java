package com.skillsync_backend.model;

public enum GroupRole {
    OWNER,
    MEMBER,
    ADMIN
}
