package com.skillsync_backend.dto;

import lombok.Setter;
import lombok.Getter;

@Getter
@Setter
public class GroupRequest {
    private String name;
    private String description;
}
