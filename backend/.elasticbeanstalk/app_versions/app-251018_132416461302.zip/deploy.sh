#!/bin/bash

# AWS Elastic Beanstalk Deployment Script for SkillSync Backend

echo "🚀 Deploying SkillSync Backend to AWS Elastic Beanstalk..."

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    echo "❌ AWS CLI is not installed. Please install it first:"
    echo "   https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
    exit 1
fi

# Check if EB CLI is installed
if ! command -v eb &> /dev/null; then
    echo "❌ EB CLI is not installed. Please install it first:"
    echo "   pip install awsebcli"
    exit 1
fi

# Check AWS credentials
echo "🔐 Checking AWS credentials..."
if ! aws sts get-caller-identity &> /dev/null; then
    echo "❌ AWS credentials not configured. Please run:"
    echo "   aws configure"
    exit 1
fi

echo "✅ AWS credentials configured"

# Build the application
echo "🔨 Building application..."
mvn clean package -DskipTests

if [ $? -ne 0 ]; then
    echo "❌ Build failed"
    exit 1
fi

echo "✅ Build successful"

# Initialize EB if not already done
if [ ! -f ".elasticbeanstalk/config.yml" ]; then
    echo "📝 Initializing Elastic Beanstalk application..."
    eb init --platform "Corretto 17" --region us-east-1
fi

# Create environment if it doesn't exist
echo "🌍 Creating/updating Elastic Beanstalk environment..."
eb create skill-sync-backend --instance-type t3.micro --platform "Corretto 17"

if [ $? -ne 0 ]; then
    echo "⚠️  Environment might already exist, trying to deploy..."
fi

# Deploy the application
echo "🚀 Deploying to Elastic Beanstalk..."
eb deploy

if [ $? -eq 0 ]; then
    echo "✅ Deployment successful!"
    echo "🌐 Getting application URL..."
    eb status
    echo ""
    echo "🎉 Your backend is now deployed!"
    echo "📝 Update your frontend's NEXT_PUBLIC_API_BASE environment variable with the URL above"
else
    echo "❌ Deployment failed"
    exit 1
fi

